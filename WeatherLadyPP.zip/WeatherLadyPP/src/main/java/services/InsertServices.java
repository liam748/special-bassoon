package services;

import decorator.AddLocationInterface;

public class InsertServices {
    public static void main(String[] args) {
        String country = "RUSSIA";
        String city =  "EUROPE";
        Double longitude = 65.0;
        Double latitude = -75.5;
//        AddLocationInterface
    }
}
