package services;
import entities.*;
import org.hibernate.Session;
import org.hibernate.query.Query;
import utilities.HibernateUtil;
import java.util.Scanner;
import java.util.List;

public class SelectServices {
    public static void main(String[] args) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();

        Query<LocationEntity> locationEntityQuery = session.createQuery("from LocationEntity ", LocationEntity.class);
        List<LocationEntity> locationEntityList = locationEntityQuery.list();
        System.out.println("INPUT COUNTRY NAME");
        Scanner scanner = new Scanner(System.in);
        String tempStr = scanner.next();

        System.out.println("# of Records in location table : " + locationEntityList.size());

        for (LocationEntity locationEntity: locationEntityList){
            if (locationEntity.getCountryName().toString().equalsIgnoreCase(tempStr)){
                System.out.println("Country Name : " + locationEntity.getCountryName());
                System.out.println("City Name : " + locationEntity.getCityName());
                System.out.println("Longitude : " + locationEntity.getLongitude());
                System.out.println("Latitude : " + locationEntity.getLatitude());
                break;
            } if (!locationEntity.getCountryName().toString().equalsIgnoreCase(tempStr)) {
                System.out.println("COUNTRY NOT FOUND");
                break;
            }
        }

        for (LocationEntity locationEntity: locationEntityList){
            System.out.println(locationEntity.getCountryName());
        }
        Query<WeatherEntity> weatherEntityQuery = session.createQuery("from WeatherEntity ",WeatherEntity.class);
        List<WeatherEntity> weatherEntityList = weatherEntityQuery.list();

        tempStr ="";

        System.out.println();

        session.close();
    }
}
