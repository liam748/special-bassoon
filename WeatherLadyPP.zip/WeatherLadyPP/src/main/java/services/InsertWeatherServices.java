package services;

import entities.LocationEntity;
import entities.WeatherEntity;
import org.hibernate.Session;
import utilities.HibernateUtil;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class InsertWeatherServices {
    public void addWeather(){
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();

        LocationEntity locationEntity = new LocationEntity();
        locationEntity.setCountryName("RUSSIA");
        locationEntity.setCityName("MOSCOW");
        locationEntity.setLongitude(175.0);
        locationEntity.setLatitude(-175.0);
        locationEntity.setLocationId(24);

        session.save(locationEntity);
        tempValidation(locationEntity, session);
        session.getTransaction().commit();
        session.close();
        System.out.println("Weather Inserted");
    }

    public void tempValidation ( LocationEntity locationEntity, Session session){
        List<WeatherEntity> weatherEntityList = new ArrayList<>();


        for (int i = 0; i < 7; i++){

            DecimalFormat df = new DecimalFormat("###.#");
            LocalDate localDate = LocalDate.now();
            double randomNum = Math.random() * 100;
            int random = (int) randomNum;
            WeatherEntity weatherEntity = new WeatherEntity();


            weatherEntity.setTemperature(Double.parseDouble(df.format(Math.random() * 1000)));
            weatherEntity.setHumidity(Double.parseDouble(df.format(Math.random()    * 1000)));
            weatherEntity.setPressure(Double.parseDouble(df.format(Math.random()    * 1000)));
            weatherEntity.setWindDirection(random);
            weatherEntity.setWindSpeed(Double.parseDouble(df.format(Math.random()   * 100)));
            weatherEntity.setWeatherDate(localDate.plusDays(i));
            weatherEntity.setLocationByLocationId(locationEntity);

            weatherEntityList.add(weatherEntity);


        }
        for (WeatherEntity weather: weatherEntityList){
            System.out.println(weather.getTemperature());
            session.save(weather);

        }

    }
}
