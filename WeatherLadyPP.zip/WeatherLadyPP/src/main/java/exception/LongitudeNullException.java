package exception;

public class LongitudeNullException extends RuntimeException{
    public LongitudeNullException (final String message){
        super(message);
    }
}
