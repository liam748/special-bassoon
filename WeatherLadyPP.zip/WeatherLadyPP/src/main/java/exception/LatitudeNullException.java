package exception;

public class LatitudeNullException extends RuntimeException{
   public LatitudeNullException (final String message){
       super(message);
   }
}
