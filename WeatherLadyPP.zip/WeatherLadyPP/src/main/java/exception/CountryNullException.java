package exception;

public class CountryNullException extends RuntimeException{
    public CountryNullException(final String message ) {
        super(message);
    }
}
