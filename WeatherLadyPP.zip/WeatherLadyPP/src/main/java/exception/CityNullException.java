package exception;

public class CityNullException extends RuntimeException{
    public CityNullException (final String message) {
        super(message);
    }
}
