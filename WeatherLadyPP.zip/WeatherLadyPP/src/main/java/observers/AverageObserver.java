package observers;

public class AverageObserver {
}
