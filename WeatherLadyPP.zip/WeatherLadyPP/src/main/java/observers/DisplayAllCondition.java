package observers;

public class DisplayAllCondition {
}
