package observers;

public interface Observer {
    void update(float var1, float var2, float var3);

    void display();
}
