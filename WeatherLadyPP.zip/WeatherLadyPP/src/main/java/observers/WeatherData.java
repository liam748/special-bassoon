package observers;

import java.util.ArrayList;

public class WeatherData implements Subject {
    private ArrayList<Observer> observers = new ArrayList();

    @Override
    public void registerObserver(Observer var1) {

    }

    @Override
    public void removeObserver(Observer var1) {

    }

    @Override
    public void notifyObserver() {

    }
}
