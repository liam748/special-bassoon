package observers;

public class ForecastObserver {
}
