package entities;

import javax.persistence.*;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "location", schema = "weatherlady")
public class LocationEntity {
    private int locationId;
    private double latitude;
    private double longitude;
    private String cityName;
        private String countryName;
    private List<WeatherEntity> weatherEntityListByLocationId;

    @Id
    @Column(name = "location_id", nullable = false)
    public int getLocationId() {
        return locationId;
    }

    public void setLocationId(int locationId) {
        this.locationId = locationId;
    }

    @Basic
    @Column(name = "latitude", nullable = false, precision = 0)
    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    @Basic
    @Column(name = "longitude", nullable = false, precision = 0)
    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    @Basic
    @Column(name = "city_name", nullable = false, length = 50)
    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    @Basic
    @Column(name = "country_name", nullable = false, length = 50)
    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LocationEntity that = (LocationEntity) o;
        return locationId == that.locationId && Double.compare(that.latitude, latitude) == 0 && Double.compare(that.longitude, longitude) == 0 && Objects.equals(cityName, that.cityName) && Objects.equals(countryName, that.countryName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(locationId, latitude, longitude, cityName, countryName);
    }
    @OneToMany(
            mappedBy = "locationByLocationId"
    )
    public List<WeatherEntity> getWeatherByLocationId() {
        return this.weatherEntityListByLocationId;
    }

    public void setWeatherByLocationId(List<WeatherEntity> weatherByLocationId) {
        this.weatherEntityListByLocationId = weatherByLocationId;
    }
}
