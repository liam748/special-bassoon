package entities;

import javax.persistence.*;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

@Entity
@Table(name = "weather", schema = "weatherlady", catalog = "")
public class WeatherEntity {
    private int weatherId;
    private double temperature;
    private double pressure;
    private double humidity;
    private int windDirection;
    private double windSpeed;
    private LocalDate weatherDate;
    private LocationEntity locationByLocationId;

    @Id
    @Column(name = "weather_id", nullable = false)
    public int getWeatherId() {
        return weatherId;
    }

    public void setWeatherId(int weatherId) {
        this.weatherId = weatherId;
    }

    @Basic
    @Column(name = "temperature", nullable = false, precision = 0)
    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }

    @Basic
    @Column(name = "pressure", nullable = false, precision = 0)
    public double getPressure() {
        return pressure;
    }

    public void setPressure(double pressure) {
        this.pressure = pressure;
    }

    @Basic
    @Column(name = "humidity", nullable = false, precision = 0)
    public double getHumidity() {
        return humidity;
    }

    public void setHumidity(double humidity) {
        this.humidity = humidity;
    }

    @Basic
    @Column(name = "wind_direction", nullable = false)
    public int getWindDirection() {
        return windDirection;
    }

    public void setWindDirection(int windDirection) {
        this.windDirection = windDirection;
    }

    @Basic
    @Column(name = "wind_speed", nullable = false, precision = 0)
    public double getWindSpeed() {
        return windSpeed;
    }

    public void setWindSpeed(double windSpeed) {
        this.windSpeed = windSpeed;
    }

    @Basic
    @Column(name = "weather_date", nullable = false)
    public LocalDate getWeatherDate() {
        return weatherDate;
    }

    public void setWeatherDate(LocalDate weatherDate) {
        this.weatherDate = weatherDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WeatherEntity that = (WeatherEntity) o;
        return weatherId == that.weatherId && Double.compare(that.temperature, temperature) == 0 && Double.compare(that.pressure, pressure) == 0 && Double.compare(that.humidity, humidity) == 0 && windDirection == that.windDirection && Double.compare(that.windSpeed, windSpeed) == 0 && Objects.equals(weatherDate, that.weatherDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(weatherId, temperature, pressure, humidity, windDirection, windSpeed, weatherDate);
    }

    @ManyToOne
    @JoinColumn(name = "location_id", referencedColumnName = "location_id", nullable = false)
    public LocationEntity getLocationByLocationId() {
        return locationByLocationId;
    }

    public void setLocationByLocationId(LocationEntity locationByLocationId) {
        this.locationByLocationId = locationByLocationId;
    }
}
