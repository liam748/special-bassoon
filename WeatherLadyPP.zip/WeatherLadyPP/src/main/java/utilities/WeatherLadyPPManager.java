package utilities;

import entities.LocationEntity;
import org.hibernate.Session;
import org.hibernate.query.Query;
import services.InsertWeatherServices;

import java.util.Iterator;
import java.util.List;

public class WeatherLadyPPManager {
    public static void main(String[] args) {
//        Session session = HibernateUtil.getSessionFactory().openSession();
//        session.beginTransaction();
//        Query<LocationEntity> locationEntityQuery = session.createQuery("from LocationEntity ", LocationEntity.class);
//        List<LocationEntity> locationEntityList = locationEntityQuery.list();
//        System.out.println("# of Records in location table : " + locationEntityList.size());
//
//        for (LocationEntity locationEntity: locationEntityList){
//            System.out.println(locationEntity.getCountryName());
//        }
//
//        session.close();
//        session.getSessionFactory().close();

        InsertWeatherServices insertWeatherServices = new InsertWeatherServices();
        insertWeatherServices.addWeather();
    }

}