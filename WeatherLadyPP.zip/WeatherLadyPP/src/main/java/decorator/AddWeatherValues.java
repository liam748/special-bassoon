package decorator;

public class AddWeatherValues {
}
