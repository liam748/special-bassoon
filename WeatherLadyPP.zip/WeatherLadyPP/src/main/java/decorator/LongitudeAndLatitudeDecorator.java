package decorator;

public class LongitudeAndLatitudeDecorator {
}
