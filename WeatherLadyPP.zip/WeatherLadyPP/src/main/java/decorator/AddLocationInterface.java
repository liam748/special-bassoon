package decorator;

import exception.CityNullException;
import exception.CountryNullException;
import exception.LatitudeNullException;
import exception.LongitudeNullException;

public interface AddLocationInterface {
    public String addCountry () throws CountryNullException;
    public String addCity() throws CityNullException;
    public Double addLongitude() throws LatitudeNullException;
    public Double addLatitude() throws LongitudeNullException;
}
