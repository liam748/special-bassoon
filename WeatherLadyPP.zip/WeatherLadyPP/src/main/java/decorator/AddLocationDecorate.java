package decorator;

public class AddLocationDecorate {
}
