package decorator;

public class NotifyDecorator {
}
