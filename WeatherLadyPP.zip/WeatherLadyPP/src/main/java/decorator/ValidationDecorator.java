package decorator;

import exception.CityNullException;
import exception.CountryNullException;
import exception.LatitudeNullException;
import exception.LongitudeNullException;

public class ValidationDecorator implements AddLocationInterface{
    private final AddLocationInterface addLocationInterface;
    public ValidationDecorator(final AddLocationInterface addLocationInterface)
    { this.addLocationInterface = addLocationInterface;
    }

    @Override
    public String addCountry() throws CountryNullException {
        String country = addLocationInterface.addCountry();
        if (country.equals("") ){
            throw new CountryNullException("Empty Country Failed");
        }
        return null;
    }

    @Override
    public String addCity() throws CityNullException {
        String city = addLocationInterface.addCity();
        if(city.equals("")){
            throw new CityNullException("Empty City Failed");
        }
        return null;
    }

    @Override
    public Double addLongitude() throws LongitudeNullException {
        Double longitude = addLocationInterface.addLongitude();
        if (longitude.equals("")){
            throw new LongitudeNullException("Empty Longitude Failed");
        }
        if (longitude > 180 || longitude < -180){
            throw new LongitudeNullException("Exceeded Limit Longitude");
        }
        return null;
    }

    @Override
    public Double addLatitude() throws LatitudeNullException {
        Double latitude = addLocationInterface.addLatitude();
        if (latitude.equals("")){
            throw  new LatitudeNullException("Empty Latitude Failed");
        }
        if (latitude > 90 || latitude < -90){
            throw new LatitudeNullException("Exceeded Limit Latitude");
            }
        return null;
    }
}

